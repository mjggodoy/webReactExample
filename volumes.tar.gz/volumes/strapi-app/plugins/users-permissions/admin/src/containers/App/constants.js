/*
 *
 * App constants
 *
 */
