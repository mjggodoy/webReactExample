/**
 *
 * Remove
 */

import React from 'react';

import styles from './styles.scss';

const Remove = (props) => <span className={styles.remove} {...props} />;

export default Remove;
