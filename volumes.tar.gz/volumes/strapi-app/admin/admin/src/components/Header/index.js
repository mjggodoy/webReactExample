/**
*
* Header
*
*/

import React from 'react';
import styles from './styles.scss';

export default function Header() {
  return <div className={styles.header} />;
}
